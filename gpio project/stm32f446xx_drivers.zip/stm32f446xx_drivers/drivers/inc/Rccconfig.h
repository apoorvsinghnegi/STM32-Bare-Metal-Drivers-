/*
 * Rccconfig.h
 *
 *  Created on: 28-Jun-2021
 *      Author: Apoorv singh negi
 */

#ifndef INC_RCCCONFIG_H_
#define INC_RCCCONFIG_H_

#include "stm32f446xx.h"


void SysClockConfig (void);
#endif /* INC_RCCCONFIG_H_ */
