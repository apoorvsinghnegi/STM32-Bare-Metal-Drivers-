/*
 * delay.h
 *
 *  Created on: 29-Jun-2021
 *      Author: Apoorv singh negi
 */

#ifndef INC_DELAY_H_
#define INC_DELAY_H_

void TIM6Config (void);

void Delay_us (uint16_t us);

void Delay_ms (uint16_t ms);


#endif /* INC_DELAY_H_ */
